package com.aimod.mod;

import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(AiPlayerMod.MOD_ID)
public class AiPlayerMod {
    public static final String MOD_ID = "aiplayermod";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public AiPlayerMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Entity tiplerini kaydet
        FoxAIEntity.ENTITY_TYPES.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::clientSetup);
        modEventBus.addListener(this::onRegisterRenderers);

        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("[AI Player Mod] FoxAI Modu yükleniyor...");
        LOGGER.info("[AI Player Mod] Botu çağırmak için: /spawn foxai");
        LOGGER.info("[AI Player Mod] Komut vermek için: {} <komut>", ModConfig.getTriggerPrefix());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // Entity attribute'larını kaydet
        event.enqueueWork(() -> {
            net.minecraftforge.event.entity.EntityAttributeCreationEvent.class.getName();
        });
        LOGGER.info("[AI Player Mod] Ortak kurulum tamamlandı.");
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        LOGGER.info("[AI Player Mod] İstemci kurulumu tamamlandı.");
    }

    @SubscribeEvent
    public void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(FoxAIEntity.FOXAI.get(), FoxAIEntity.Renderer::new);
    }
}
